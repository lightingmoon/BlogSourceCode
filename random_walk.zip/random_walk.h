#ifndef RANDOM_WALK_H
#define RANDOM_WALK_H

#include<iostream>
#include<vector>
#include<map>
#include<tuple>
#include<string>
#include<random>
#include<fstream>
#include<sstream>
#include <utility>
#include<set>
#include<algorithm>
#include<cstdlib>
#include<ctime>
using namespace TSnap;	// ʹ��Snap�����ռ�

using std::to_string;
using std::random_device;
using std::default_random_engine;
using std::uniform_int_distribution;
using std::uniform_real_distribution;
using std::tuple;
using std::vector;
using std::map;
using std::set;
using std::string;
using std::endl;
using std::cout;

vector<string> get_random_walk_road(const PUNGraph&, const int, const int, const map<string, int>&, const vector<vector<int>>&);
tuple<int, int, int> get_random_out(const PUNGraph&, const int&, const int&, const int&, const map<string, int>&, const vector<vector<double>>&);
#endif