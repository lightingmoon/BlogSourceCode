#include "stdafx.h"
#include "random_walk.h"
constexpr auto MAX_WALK_LENGTH = 50;
constexpr auto MAX_WALK_TIMES = 10;
constexpr auto WINDOW = 10;
constexpr auto SEQ_PATH = "D:\\sequence\\";


vector<string> get_random_walk_road(const PUNGraph &G, const int start_node_id, const int max_walk_length,
    const map<string, int>& edgetype_dic, const vector<vector<double>>& transition_matrix)
{
    vector<string> Road_list = {};
    int next_node_id = start_node_id;
    
    Road_list.push_back(to_string(start_node_id)); //���뿪ʼ���

    // ѡȡ��ʼ�漴�ڵ����һ���ڵ�
    size_t out_deg = G->GetNI(next_node_id).GetDeg();

    std::random_device rd;
    default_random_engine e{ rd() };
    uniform_int_distribution<unsigned> u(0, out_deg - 1);
    int next_next_node_id = G->GetNI(next_node_id).GetNbrNId(u(e));
    const string key = to_string(next_node_id) + " " + to_string(next_next_node_id);
    int pre_edgetype = edgetype_dic.at(key);
    
    // ÿ��ѭ������һ������߳��ȵ�����
    for (int i = 1; i < max_walk_length; i++)
    {
        Road_list.push_back(to_string(next_next_node_id));

        tuple<int, int, int> res = get_random_out(G, next_next_node_id, pre_edgetype, next_node_id, edgetype_dic, transition_matrix);

        if (std::get<0>(res) == -1)
        {
            // ������һ�����Ȳ�Ϊ0�Ľ��
            next_node_id = G->GetRndNId();
            size_t out_deg = G->GetNI(next_node_id).GetDeg();
            while (out_deg == 0)
            {
                next_node_id = G->GetRndNId();
                out_deg = G->GetNI(next_node_id).GetDeg();
            }
            
            uniform_int_distribution<unsigned> u1(0, out_deg - 1);
            next_next_node_id = G->GetNI(next_node_id).GetNbrNId(u1(e));
            const string key1 = to_string(next_node_id) + " " + to_string(next_next_node_id);
            pre_edgetype = edgetype_dic.at(key1);
        }
        else
        {
            std::tie(next_node_id, next_next_node_id, pre_edgetype) = res;
            /*next_node_id = std::get<0>(res);
            next_next_node_id = std::get<1>(res);
            pre_edgetype = std::get<2>(res);*/
        }
        
        //������
       // break;
    }
    return Road_list;
}

tuple<int, int, int> get_random_out(const PUNGraph& G, const int& In_Node_ID, const int& Pre_Edgetype_ID, const int& Last_Node_ID, 
    const map<string, int>& edgetype_dic, const vector<vector<double>>& mtx)
{
    // ��ȡ��ö����ڽӵı�����
    set<int> nb_edgetype;
    size_t out_deg = G->GetNI(In_Node_ID).GetDeg(); // ��ȡ�ý��Ķ�
    if (out_deg == 0) // ������Ϊ0���ضϷ���
        return std::make_tuple(-1, 0, 0);

    vector<int> out_edge_id; // ��ȡ�����ڽӽ��ID
    for (size_t i = 0; i < out_deg; ++i)
    {
        int nb_id = G->GetNI(In_Node_ID).GetNbrNId(i);
        out_edge_id.push_back(nb_id);
        const string key = to_string(In_Node_ID) + " " + to_string(nb_id);
        nb_edgetype.insert(edgetype_dic.at(key));
    }
   // cout << "��������: " << nb_edgetype.size() << endl;

    // ֻ��һ�ֳ������ͣ� ���ѡһ�����߼���
    int edgetype_trans = -1; // ��¼��������
    int trans_id = -1; // ��¼����id
    if (nb_edgetype.size() == 1)
    {
        std::random_device rd;
        default_random_engine e{rd()};
        uniform_int_distribution<unsigned> u(0, out_deg - 1);
        trans_id = G->GetNI(In_Node_ID).GetNbrNId(u(e));
        edgetype_trans = *(begin(nb_edgetype));

       /* cout << "����1" << endl;
        cout << "in:" << In_Node_ID << ", out_id: " << trans_id << ", trans_type: " << edgetype_trans << endl;*/
    }
    else 
    {
        // ת�Ƶı����ͱ�������ڳ�����
        while (nb_edgetype.count(edgetype_trans) == 0)
        {
            edgetype_trans = -1;
            std::random_device rd;
            default_random_engine e{ rd() };
            std::uniform_real_distribution<double> distribution(0.0, 1.0);
            double random_number = distribution(e);


            double calc_p = 0.0;
            int temp_index = 0;
            for (size_t i = 0; i < mtx.size(); ++i)
            {
                calc_p += mtx[Pre_Edgetype_ID].at(i);
                if (random_number < calc_p)
                {
                    temp_index = i;
                    break;
                }
            }

            edgetype_trans = temp_index;
        }
       
        // ѡ��ת�ƵĽ��
        vector<int> t_vec = {}; // ��¼������Ŀ��ת�Ʊ����͵ĳ���
        
        for (size_t i = 0; i < out_edge_id.size(); ++i)
        {
            const string key = to_string(In_Node_ID) + " " + to_string(out_edge_id.at(i));
            if (edgetype_trans == edgetype_dic.at(key))
                t_vec.push_back(out_edge_id.at(i));
        }
        std::random_device rd;
        default_random_engine e{ rd() };
        uniform_int_distribution<unsigned> u(0, t_vec.size() - 1);
        
        trans_id = u(e);
       /* cout << "����2" << endl;
        cout << "in:" << In_Node_ID << ", out_id: " << trans_id << ", trans_type: " << edgetype_trans << endl;*/
    }
    
    return std::make_tuple(In_Node_ID, trans_id, edgetype_trans);
}

map<string, int> init_edgetype_dic(const string& path)
{
    map<string, int> dic;
    std::fstream open(path.c_str(), std::ios::in);
    if (!open.is_open())
    {
        cout << "�ļ���ȡʧ�ܣ�" << endl;
        exit(-1);
    }
    string tmp;
    while (getline(open, tmp))
    {
        std::stringstream tstr(tmp);
        int t;
        vector<int> ps;
        while (tstr >> t)
        {
            ps.push_back(t);
            tstr.ignore(1);
        }
        tmp = to_string(ps[0]) + " " + to_string(ps[1]);
        dic[tmp] = ps[2];
        tmp = to_string(ps[1]) + " " + to_string(ps[0]);
        dic[tmp] = ps[2];
    }
    return dic;
}
vector<vector<double>> init_transition_matrix(const string& path)
{
    vector<vector<double>> mtx;
    std::fstream open(path.c_str(), std::ios::in);
    if (!open.is_open())
    {
        cout << "�ļ���ȡʧ�ܣ�" << endl;
        exit(-1);
    }
    string tmp;
    while (getline(open, tmp))
    {
        std::stringstream tstr(tmp);
        size_t id = 0;
        double t;
        vector<double> tmp;
        while (tstr >> t)
        {
            tmp.push_back(t);
            tstr.ignore(1);
        }
        mtx.push_back({ tmp });
        id++;
        cout << mtx.size() << endl;
    }
    return mtx;
}


int main() {
    // ����ͼ
    cout << "��ʼ�������������..." << endl;
    clock_t start, end;
    start = clock();
    const TStr graph_path = "C:\\Users\\Administrator\\workspace\\edgetype2vec\\edgelist.csv";
    PUNGraph G = TSnap::LoadEdgeList<PUNGraph>(graph_path, 0, 1, '\t');
    const map<string, int> dic = init_edgetype_dic("C:\\Users\\Administrator\\workspace\\edgetype2vec\\edgelist_map_type.csv");
    const vector<vector<double>> transition_matrix = init_transition_matrix("C:\\Users\\Administrator\\workspace\\edgetype2vec\\TransitionMatrix.csv");
    cout << transition_matrix.size() << endl;
   
    std::string seq_name = to_string(MAX_WALK_LENGTH) + "(len)_" + to_string(MAX_WALK_TIMES) + string("(times)");
    string seq_path_all = SEQ_PATH + seq_name + ".txt";
    cout << seq_path_all << endl;
    std::fstream fout(seq_path_all, std::ofstream::app);
    if (!fout.is_open())
    {
        cout << "���ļ�ʧ�ܣ�" << endl;
        exit(-1);
    }
    end = clock();
    cout << "��ʼ�����в�����ɣ�time = " << double(end - start) / CLOCKS_PER_SEC << "s" << endl;
    cout << "��ʼ��������в���..." << endl;
    start = clock();
    // ��ÿ�������в���
    set<int> count_vex;
    for (size_t t = 0; t < G->GetNodes(); ++t)
    {
        int rd_id = t;
        
        for (size_t i = 0; i < MAX_WALK_TIMES; ++i)
        {
            auto road_list = get_random_walk_road(G, rd_id, MAX_WALK_LENGTH, dic, transition_matrix);
            
            for (auto& s : road_list)
            {
                fout << s << " ";
                count_vex.insert(atoi(s.c_str()));
            }
            cout << to_string(count_vex.size()) + "Nodes have visited..." << endl;
            fout << endl;
        }
        fout.close();
        cout << endl;
    }
    end = clock();
    cout << "�������...time= " << double(end - start) / CLOCKS_PER_SEC <<"s"<< endl;
    cout << "��ʼ����ѵ��..."<<endl;
    start = clock();
    const string comm = "E:\\word2vec_cpp.exe -train \"" + seq_path_all + "\" -output \""+ SEQ_PATH + seq_name +".vec" + "\" -lr 1e-3 -size 128 -threads 16 -window " + to_string(WINDOW) + "-iter 5 -cbow 0 -min-count 0";
    system(comm.c_str());
    end = clock();
    cout << "ѵ�����...time= " << double(end - start) / CLOCKS_PER_SEC << "s" << endl;
    return 0;
}
